<!DOCTYPE html>
<html>
<title>Thông báo bảo trì</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<body style="background: #000">
    <div >
        <h3 style="margin-top: 250px;font-style: italic;color: #fff; text-align: center">Do số lượng truy cập vượt ngưỡng nên chúng tôi cần bảo trì nâng cấp app trong thời gian ngắn. Dự kiến muộn nhất sẽ mở lại là sáng ngày mai 14.12.2020. Xin chân thành cảm ơn sự ủng hộ của quý khách hàng !</h3>
    </div>
    
</body>

</html>
