@extends('layout.master')
@section('content')
	<main id="main">
		<div class="container-fluid p-0">
			<div class="row no-gutters">
				<div class="col-12 text-center">
					<h4 class="title-block">Giới thiệu</h4>
				</div>
			</div>
			<div class="row no-gutters container-fluid">
				<div class="col-12">
<div class="alert alert-warning" style="text-align:justify" role="alert">
   Covid 19 đã ảnh hưởng không nhỏ với nền kinh tế thế giới nói chung cũng như VIỆT NAM nói riêng. Chưa kể hiện nay có rất nhiều ứng dụng kiếm tiền online mọc ra nhan nhản nhằm thu hút khách hàng đầu tư và dĩ nhiên họ hoàn toàn không có một căn cứ nào để làm ra tiền và trả cho các bạn. Đứng trước tình thế đó, chúng tôi tập đoàn lớn tại SINGGAPO đã tạo ra app VIPPRO.ORG với mục tiêu hỗ trợ phần nào cho tất cả người việt kiếm thêm chút thu nhập trong thời kì covid trên cơ sở mua bán hàng online qua các trang thương mại lớn như lazada, tiki......và sự ủng hộ của các bạn sẽ mang lại hoa hồng 20% cho mỗi một đơn hàng , nếu như tất cả hàng chục triệu người biết mua bán hàng qua mạng 4.0 thì sẽ mang lại một nguồn thu nhập không nhỏ. Chúng tôi sẵn sàng chi ra 10% lợi nhuận và trả hoa hồng cho các bạn qua việc chia sẻ link lên zalo, facebook cũng như cày view qua các kênh video của các youtober ......Hãy biết đầu tư đúng nơi. Phải biết chọn đúng app có cơ sở kiếm ra tiền và trả tiền cho các bạn. Hãy vì một cộng đồng kiếm tiền online, hãy chung tay xây dựng app VIPPRO.ORG ngày một lớn mạnh. Xin chân thành cảm ơn 
</div>

				</div>
			</div>
		</div>
	</main>
@endsection