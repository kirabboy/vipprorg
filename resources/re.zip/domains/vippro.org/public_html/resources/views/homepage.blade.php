@extends('layout.master')
@section('content')
<main id="main">
    <div class="container-fluid p-0">
        <div style="background:rgb(25, 26, 26)">
            <div class="row no-gutters">
                <div class="col-12">
                    <!-- Add images to <div class="fotorama"></div> -->
                    <div class="fotorama" data-autoplay="true">
                        @foreach($banners as $val)
                            <img src="{{asset("/resources/image/img_app/".$val->name)}}">
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="row no-gutters">
                <div class="col-12">
                    <div class="ranking block"  onclick="location.href='{{URL::to('/rank')}}'">
                        <h4 class="title-block">Bảng xếp hạng</h4>
                        <img src="{{asset('/resources/image/img_app/ranking_vip.png')}}"/>
                    </div>
                    
                </div>
            </div>
            <marquee class="notice-spin block">
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 1: <span class="sdt">✳✳✳✳✳✳4561</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 2: <span class="sdt">✳✳✳✳✳✳3451</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 3: <span class="sdt">✳✳✳✳✳✳8231</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 4: <span class="sdt">✳✳✳✳✳✳9323</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 5: <span class="sdt">✳✳✳✳✳✳5621</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 6: <span class="sdt">✳✳✳✳✳✳0812</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 7: <span class="sdt">✳✳✳✳✳✳4231</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 8: <span class="sdt">✳✳✳✳✳✳5423</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 9: <span class="sdt">✳✳✳✳✳✳1835</span></span>
                <span class="spin-not"><img  src="{{asset("/resources/image/img_app/vip-avatar.png")}}"/>Top 10: <span class="sdt">✳✳✳✳✳✳1782</span></span>
                
            </marquee>
            <div class="row no-gutters">
                <div class="col-12">
                    <div class="shopping block" onclick="location.href='{{URL::to('/shopping')}}'">
                        <i class="fa fa-shopping-cart"></i> <span class="shopping-text">Mua sắm</span>
                    </div>
                </div>
            </div>
            <div class="row no-gutters block">
                <div class="col-6">
                    <div class="text-center ">
                        <div class="progress">
                            <div  class="progress-bar progress-bar-striped bg-info progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">
                                <i style=" color: #89ff89;"class="fa fa-shopping-basket"><span style=" color: #fff"> <?php echo(number_format(rand(1000,2000),0,',','.')); ?> đơn hàng đã được mua</span></i> 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="text-center" >
                        <div class="progress">
                            <div  class="progress-bar progress-bar-striped bg-success progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                <i style=" color:#89ff89;" class="fa fa-circle"><span style="color: #fff"> <?php echo(number_format(rand(100000,500000),0,',','.')); ?> thành viên online</span></i> 
                            </div>
                          </div>
                    </div>
                </div>
            </div>
            <div class="row no-gutters">
                <div class="col-12">
                    <div class="flashsale block">
                       
                        <h4 class="title-block"> 
                            <img width="25px" src="{{asset("/resources/image/img_app/star_gold.png")}}"/> 
                            Flash sale
                        </h4>
                        <marquee  class="form-control"/><span>{{$notice->content}}</span></marquee>
                    </div>
                </div>
            </div>
    
            <div class="row no-gutters">
                <div class="col-6">
                    <div class="gioi-thieu text-center block" onclick="location.href='{{URL::to('/introduce')}}'">
                        <i class="fa fa-info-circle"></i><span> Giới thiệu</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="giai-dap text-center block"  onclick="location.href='{{URL::to('/helpcenter')}}'">
                        <i class="fa fa-question-circle"></i><span> Giải đáp</span>
                    </div>
                </div>
            </div>
            
            <div class="row no-gutters">
                <div class="col-6">
                    <div class="hotro block">
                        <h4 class="title-block">Hỗ trợ 24/7</h4>
                        <img  src="{{asset("/resources/image/img_app/tuvan.png")}}" onclick="location.href='{{URL::to('/contact')}}'"/>
                    </div>
                </div>
                <div class="col-6">
                    <div class="hotro block">
                        <h4 class="title-block">Mua điểm VIP</h4>
                        <img  src="{{asset("/resources/image/img_app/vip-upgrade.png")}}" onclick="location.href='{{URL::to('/buycoin')}}'"/>
                    </div>
                </div>
            </div>
            <div class="row no-gutters">
                <div class="col-12">
                    <div class="modal fade" id="quanotice" role="dialog">
                        <div class="modal-dialog  modal-dialog-centered">
                        
                          <!-- Modal content-->
                          <div class="modal-content">
                            <div class="modal-header text-center">
                              <h4 class="modal-title">Nhận thưởng hàng ngày</h4>
                            </div>
                            <div class="modal-body text-center" style="color: #fff">
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
                            </div>
                          </div>
                          
                        </div>
                      </div>
                    <div class="qua block">
                        <h4 class="title-block">Hộp quà may mắn</h4>
                        <img onclick="location.href='{{URL::to('/get-gift')}}'" src="{{asset("/resources/image/img_app/gift.png")}}"/>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection